from find_gcd import gcd

if __name__ == '__main__': 
     result = gcd(48,  64) 
     if result != 16: 
         print("Test failed")
print("Test Passed")

